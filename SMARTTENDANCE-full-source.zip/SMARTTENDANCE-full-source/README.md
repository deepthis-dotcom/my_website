# SMARTTENDANCE — Full-stack starter

A learning-oriented starter for a BLE-assisted attendance platform.

## What's included
- React + Vite frontend with role-aware pages, dashboard, student list, attendance view, shortage alerts and report CSV export.
- Express API using Firebase Admin SDK and Firestore.
- Firebase client authentication setup and Firestore security rules.
- Flutter Android app starter with student BLE advertising and faculty BLE scanning.
- Attendance percentage / shortage calculation utilities.

## Important status
This is a functional **starter architecture**, not a production-ready attendance product. The Flutter BLE layer is a prototype and BLE behavior varies by Android version/device. A detected BLE packet is only a proximity signal, not proof that a student is physically present. Before real deployment, implement server-issued rotating tokens, device/user binding, replay protection, rate limiting, audit trails, institution-approved consent, and independent faculty verification. Do not use real student data until Firebase rules, authentication, backend authorization and deployment secrets are configured and reviewed.

## Requirements
- Node.js LTS and npm
- Flutter SDK + Android Studio (for the mobile app)
- A Firebase project with Authentication (Email/Password) and Firestore enabled

## 1. Frontend
```bash
cd frontend
npm install
cp .env.example .env
# Fill in Firebase web app values in .env
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173).

## 2. Backend
In another terminal:
```bash
cd backend
npm install
cp .env.example .env
```
Create a Firebase service account in Firebase Console → Project settings → Service accounts. Set `FIREBASE_SERVICE_ACCOUNT_JSON` to the **single-line JSON** service account contents, or use `GOOGLE_APPLICATION_CREDENTIALS` pointing to a local JSON file. Never commit service account credentials.
```bash
npm run dev
```
API runs at http://localhost:4000. `GET /health` checks the server.

## 3. Firebase setup
1. Create a Firebase project.
2. Enable Authentication → Sign-in method → Email/Password.
3. Create a Firestore database.
4. Register a Web App and copy its config into `frontend/.env`.
5. Deploy `firestore.rules` from the project root using Firebase CLI, after reviewing it:
```bash
firebase deploy --only firestore:rules
```
The included rules are a restrictive starting point. The API uses Firebase Admin and therefore bypasses Firestore client rules; protect API routes with verified Firebase ID tokens and role checks.

## 4. Flutter Android app
```bash
cd mobile-ble
flutter pub get
flutter run
```
Use two Android phones for a meaningful BLE test: one in Student mode (advertises a short-lived demo identifier), one in Faculty mode (scans). BLE permissions and background operation vary by Android version. For Android 12+, review the manifest permissions and request runtime permissions. Keep the app in the foreground for this prototype.

## Suggested Firestore collections
- `users/{uid}`: `{ displayName, email, role, department, createdAt }`
- `students/{studentId}`: `{ uid, name, rollNumber, department, semester, email }`
- `subjects/{subjectId}`: `{ name, code, facultyUid, semester, department }`
- `sessions/{sessionId}`: `{ subjectId, facultyUid, startsAt, endsAt, status, tokenVersion }`
- `attendance/{recordId}`: `{ sessionId, studentUid, subjectId, status, markedAt, source }`
- `notifications/{notificationId}`: `{ recipientUid, title, body, read, createdAt, type }`

## Attendance formula
`attendance % = attended classes / conducted classes × 100`.
A shortage alert is generated when the percentage is below the configured threshold (default 75%). This starter does not automatically backfill or modify attendance.

## API endpoints
- `GET /health`
- `GET /api/me` (requires Firebase ID token)
- `POST /api/sessions` (faculty/admin)
- `POST /api/attendance/mark` (faculty/admin; prototype endpoint)
- `GET /api/attendance/student/:uid` (self or admin)
- `POST /api/shortages/check` (admin/faculty; demo check)

All protected endpoints require `Authorization: Bearer <Firebase ID token>`.

## Next steps for a real institution
1. Define roles and access policies with the institution.
2. Create admin-only user provisioning; do not allow users to self-assign admin.
3. Replace demo BLE IDs with backend-issued short-lived signed challenges.
4. Validate session, subject enrollment, challenge expiry and duplicate attendance transactionally.
5. Add faculty correction workflow with mandatory reason and immutable audit record.
6. Add scheduled shortage checks and FCM/email delivery with deduplication.
7. Add tests, monitoring, backups, privacy notice and security review.
