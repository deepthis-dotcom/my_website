# Flutter BLE prototype

Run `flutter pub get` then `flutter run` on a physical Android device. For a test, use two phones:
- Student phone → Start advertising demo ID.
- Faculty phone → Start scan.

BLE advertising/scanning requires compatible hardware, runtime permissions and often foreground operation. This demo payload is random and is not authenticated. It does not call the backend or create attendance records. Implement server-issued signed ephemeral challenges before connecting BLE detection to attendance.
