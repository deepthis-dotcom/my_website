import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class FacultyScannerPage extends StatefulWidget {
  const FacultyScannerPage({super.key});
  @override
  State<FacultyScannerPage> createState() => _FacultyScannerPageState();
}
class _FacultyScannerPageState extends State<FacultyScannerPage> {
  StreamSubscription<List<ScanResult>>? _subscription;
  final Map<String, String> _seen = {};
  bool _scanning = false;

  Future<void> _start() async {
    await [Permission.bluetoothScan, Permission.bluetoothConnect, Permission.locationWhenInUse].request();
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 30), withServices: [Guid('7b9e0001-6d2a-4c1b-9f2a-123456789abc')]);
      _subscription = FlutterBluePlus.scanResults.listen((results) {
        for (final result in results) {
          final manufacturer = result.advertisementData.manufacturerData;
          final demo = manufacturer[0xFFFF];
          if (demo != null) {
            final id = demo.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
            if (mounted) setState(() => _seen[result.device.remoteId.str] = id);
          }
        }
      });
      if (mounted) setState(() => _scanning = true);
    } catch (e) {
      _message('Scan failed: $e');
    }
  }

  Future<void> _stop() async {
    await FlutterBluePlus.stopScan();
    await _subscription?.cancel();
    if (mounted) setState(() => _scanning = false);
  }
  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override
  void dispose() { _subscription?.cancel(); FlutterBluePlus.stopScan(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Faculty BLE scanner'), actions: [IconButton(onPressed: _scanning ? _stop : _start, icon: Icon(_scanning ? Icons.stop : Icons.play_arrow))]),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(_scanning ? 'Scanning nearby devices…' : 'Scanner stopped', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      const Text('Detected demo packets only. Do not automatically mark attendance from this list.', style: TextStyle(color: Colors.orangeAccent)),
      const SizedBox(height: 12),
      Expanded(child: _seen.isEmpty ? const Center(child: Text('No matching BLE devices detected yet.')) : ListView(children: _seen.entries.map((e) => Card(child: ListTile(leading: const Icon(Icons.bluetooth), title: Text('Nearby BLE device'), subtitle: Text('Device: ${e.key}\\nDemo payload: ${e.value}'), isThreeLine: true))).toList())),
      SizedBox(width: double.infinity, child: FilledButton(onPressed: _scanning ? _stop : _start, child: Text(_scanning ? 'Stop scan' : 'Start scan'))),
    ])),
  );
}
