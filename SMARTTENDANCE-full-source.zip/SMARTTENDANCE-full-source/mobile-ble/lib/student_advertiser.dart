import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_ble_peripheral/flutter_ble_peripheral.dart';
import 'package:permission_handler/permission_handler.dart';

class StudentAdvertiserPage extends StatefulWidget {
  const StudentAdvertiserPage({super.key});
  @override
  State<StudentAdvertiserPage> createState() => _StudentAdvertiserPageState();
}

class _StudentAdvertiserPageState extends State<StudentAdvertiserPage> {
  final _ble = FlutterBlePeripheral();
  bool _running = false;
  String _demoId = '';

  // Demo only: random ephemeral bytes, not a real authenticated attendance token.
  // Production: fetch a short-lived signed challenge from the backend after login.
  List<int> _newEphemeralBytes() => List.generate(8, (_) => Random.secure().nextInt(256));

  Future<void> _start() async {
    await [Permission.bluetoothAdvertise, Permission.bluetoothConnect].request();
    final supported = await _ble.isSupported;
    if (!supported) {
      _message('BLE advertising is not supported on this device.');
      return;
    }
    final bytes = _newEphemeralBytes();
    _demoId = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    try {
      await _ble.start(
        advertiseData: AdvertiseData(
          serviceUuid: '7b9e0001-6d2a-4c1b-9f2a-123456789abc',
          manufacturerId: 0xFFFF,
          manufacturerData: bytes,
          includeDeviceName: false,
        ),
        advertiseSettings: AdvertiseSettings(
          advertiseMode: AdvertiseMode.advertiseModeLowLatency,
          txPowerLevel: AdvertiseTxPower.advertiseTxPowerMedium,
          connectable: false,
        ),
      );
      setState(() => _running = true);
    } catch (e) { _message('Could not start BLE advertising: $e'); }
  }

  Future<void> _stop() async {
    await _ble.stop();
    if (mounted) setState(() => _running = false);
  }
  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  void dispose() { if (_running) _ble.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Student BLE advertiser')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(_running ? Icons.bluetooth_connected : Icons.bluetooth, size: 66, color: _running ? Colors.greenAccent : Colors.deepPurpleAccent),
      const SizedBox(height: 20),
      Text(_running ? 'Advertising demo identifier' : 'Not advertising', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Text(_running ? 'Ephemeral demo value: $_demoId' : 'Start advertising while the faculty test device scans.', textAlign: TextAlign.center),
      const SizedBox(height: 24),
      FilledButton(onPressed: _running ? _stop : _start, child: Text(_running ? 'Stop advertising' : 'Start advertising')),
      const SizedBox(height: 18),
      const Text('Do not use this random value to grant attendance. A production app must use a server-signed, expiring challenge.', textAlign: TextAlign.center, style: TextStyle(color: Colors.orangeAccent)),
    ]))),
  );
}
