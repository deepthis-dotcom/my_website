import 'package:flutter/material.dart';
import 'student_advertiser.dart';
import 'faculty_scanner.dart';

void main() => runApp(const SmarttendanceApp());

class SmarttendanceApp extends StatelessWidget {
  const SmarttendanceApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'SMARTTENDANCE BLE',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: const Color(0xff7868e8), brightness: Brightness.dark, useMaterial3: true),
    home: const ModePage(),
  );
}

class ModePage extends StatelessWidget {
  const ModePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SMARTTENDANCE')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.bluetooth_searching, size: 72, color: Color(0xffa99aff)),
        const SizedBox(height: 18),
        const Text('BLE attendance prototype', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Choose the role for this test device.', textAlign: TextAlign.center),
        const SizedBox(height: 30),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentAdvertiserPage())), icon: const Icon(Icons.person), label: const Text('Student — advertise demo ID')),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FacultyScannerPage())), icon: const Icon(Icons.bluetooth_searching), label: const Text('Faculty — scan nearby devices')),
        const SizedBox(height: 28),
        const Text('Prototype only. BLE detection is not proof of attendance.', style: TextStyle(color: Colors.orangeAccent), textAlign: TextAlign.center),
      ]),
    ),
  );
}
