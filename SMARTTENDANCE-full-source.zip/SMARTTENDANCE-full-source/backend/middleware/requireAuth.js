import { auth, db } from '../firebaseAdmin.js';
export async function requireAuth(req,res,next) {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) return res.status(401).json({error:'Missing bearer token'});
    const decoded = await auth.verifyIdToken(header.slice(7));
    const profile = await db.collection('users').doc(decoded.uid).get();
    if (!profile.exists) return res.status(403).json({error:'User profile not found'});
    req.user = { uid: decoded.uid, email: decoded.email, ...profile.data() };
    next();
  } catch (error) { return res.status(401).json({error:'Invalid or expired authentication token'}); }
}
export function allowRoles(...roles) {
  return (req,res,next) => roles.includes(req.user?.role) ? next() : res.status(403).json({error:'Insufficient permissions'});
}
