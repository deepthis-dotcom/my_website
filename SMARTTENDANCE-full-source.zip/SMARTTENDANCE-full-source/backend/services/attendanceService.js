import { db, FieldValue } from '../firebaseAdmin.js';

export async function createSession({subjectId, facultyUid}) {
  const subject = await db.collection('subjects').doc(subjectId).get();
  if (!subject.exists) throw new Error('Subject not found');
  if (subject.data().facultyUid !== facultyUid) throw new Error('You are not assigned to this subject');
  const ref = db.collection('sessions').doc();
  await ref.set({subjectId, facultyUid, status:'active', startsAt:FieldValue.serverTimestamp(), endsAt:null, createdAt:FieldValue.serverTimestamp()});
  return ref.id;
}

export async function markAttendance({sessionId, studentUid, facultyUid, source='faculty'}) {
  const sessionRef = db.collection('sessions').doc(sessionId);
  const attendanceRef = db.collection('attendance').doc(`${sessionId}_${studentUid}`);
  return db.runTransaction(async tx => {
    const sessionSnap = await tx.get(sessionRef);
    if (!sessionSnap.exists || sessionSnap.data().status !== 'active') throw new Error('Session is not active');
    const session = sessionSnap.data();
    if (session.facultyUid !== facultyUid) throw new Error('Only the session faculty can mark attendance');
    const existing = await tx.get(attendanceRef);
    if (existing.exists) return {id:attendanceRef.id, alreadyMarked:true};
    tx.set(attendanceRef, {
      sessionId, studentUid, subjectId:session.subjectId, status:'present',
      source, markedAt:FieldValue.serverTimestamp(), markedBy:facultyUid
    });
    return {id:attendanceRef.id, alreadyMarked:false};
  });
}
