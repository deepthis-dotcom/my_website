import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import api from './routes/api.js';

const app=express();
app.use(helmet());
app.use(cors({origin:process.env.FRONTEND_ORIGIN||'http://localhost:5173'}));
app.use(express.json({limit:'200kb'}));
app.use(rateLimit({windowMs:60_000,limit:120,standardHeaders:true,legacyHeaders:false}));
app.get('/health',(_req,res)=>res.json({ok:true,service:'smarttendance-api'}));
app.use('/api',api);
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Internal server error'});});
const port=Number(process.env.PORT||4000);
app.listen(port,()=>console.log(`SMARTTENDANCE API listening on http://localhost:${port}`));
