import { Router } from 'express';
import { db, FieldValue } from '../firebaseAdmin.js';
import { requireAuth, allowRoles } from '../middleware/requireAuth.js';
import { createSession, markAttendance } from '../services/attendanceService.js';
const router = Router();
router.use(requireAuth);

router.get('/me',(req,res)=>res.json({uid:req.user.uid,email:req.user.email,role:req.user.role,displayName:req.user.displayName||''}));

router.post('/sessions',allowRoles('faculty','admin'),async(req,res)=>{
  try { const {subjectId}=req.body; if(!subjectId) return res.status(400).json({error:'subjectId is required'}); const id=await createSession({subjectId,facultyUid:req.user.uid}); res.status(201).json({sessionId:id}); }
  catch(e){res.status(400).json({error:e.message});}
});

router.post('/attendance/mark',allowRoles('faculty','admin'),async(req,res)=>{
  try {
    const {sessionId,studentUid}=req.body;
    if(!sessionId||!studentUid) return res.status(400).json({error:'sessionId and studentUid are required'});
    // Prototype: this route is faculty-authorized manual marking, not BLE proof.
    const result=await markAttendance({sessionId,studentUid,facultyUid:req.user.uid,source:'faculty-manual'});
    res.status(200).json(result);
  } catch(e){res.status(400).json({error:e.message});}
});

router.get('/attendance/student/:uid',async(req,res)=>{
  if(req.params.uid!==req.user.uid && req.user.role!=='admin') return res.status(403).json({error:'Not allowed'});
  const snap=await db.collection('attendance').where('studentUid','==',req.params.uid).get();
  res.json({records:snap.docs.map(d=>({id:d.id,...d.data()}))});
});

router.post('/shortages/check',allowRoles('faculty','admin'),async(req,res)=>{
  const threshold=Number(req.body.threshold ?? 75);
  if(!Number.isFinite(threshold)||threshold<=0||threshold>=100) return res.status(400).json({error:'threshold must be between 0 and 100'});
  const students=await db.collection('students').get();
  const created=[];
  for(const doc of students.docs){
    const s=doc.data(); const attended=Number(s.attended||0), conducted=Number(s.conducted||0);
    if(!conducted) continue;
    const percentage=attended/conducted*100;
    if(percentage<threshold && s.uid){
      const dedupeId=`shortage_${s.uid}_${doc.id}_${Math.floor(Date.now()/86400000)}`;
      const ref=db.collection('notifications').doc(dedupeId);
      const exists=await ref.get();
      if(!exists.exists){
        await ref.set({recipientUid:s.uid,title:'Attendance shortage warning',body:`Your attendance is ${percentage.toFixed(1)}%, below ${threshold}%. Please contact your faculty.`,type:'shortage',read:false,createdAt:FieldValue.serverTimestamp()});
        created.push(s.uid);
      }
    }
  }
  res.json({threshold,notificationsCreated:created.length});
});
export default router;
